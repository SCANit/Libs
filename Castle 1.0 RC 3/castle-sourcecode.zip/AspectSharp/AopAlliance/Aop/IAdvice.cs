using System;

namespace AopAlliance.Aop
{
	/// <summary>
	/// Tag interface for Advice. Implementations can be any type of advice, such as Interceptors.
	/// </summary>
	public interface IAdvice
	{
	}
}
