
More information about Castle.ActiveRecord
can be found at http://www.castleproject.org/

